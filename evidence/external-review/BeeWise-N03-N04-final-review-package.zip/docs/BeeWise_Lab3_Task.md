# BeeWise Lab 3 - Task tracker theo Preparation Guide v5

> Cập nhật **02/11/2026**. Mentor nhắc: **“Lab3 tập trung vào công nghệ các bạn nhé.”**
> PR #2 và #3 **đã MERGED**. Phần Bảo đã tích hợp không đồng nghĩa toàn bộ Lab 3 hoàn thành.
> **Storage BẮT BUỘC nhưng đang DEFERRED theo quyết định chủ project: chưa hoàn thành, chưa live verified, phải giải quyết trước khi nộp đủ yêu cầu.**

## 1. Tổng quan và nguồn chuẩn

BeeWise chuyển thiết kế Lab 2 thành Flutter dùng dữ liệu thật, có ba luồng người dùng, xử lý lỗi và bằng chứng kiểm chứng được. Ưu tiên sáu dịch vụ Firebase, MVVM, ARTEMIS và demo; không mở rộng payment/backend vượt nhu cầu các luồng đã chọn.

- **Nguồn kỹ thuật hiện hành:** `PRM393_Lab3_Preparation_Guide_v5_ToiUu.pdf`, bản mentor cung cấp ngoài repo, **25 trang đã đọc đầy đủ**. Dẫn trang v5 bên dưới; không thêm PDF vào PR này.
- **Thiết kế/phạm vi app:** [handoff Lab 2](../handoff/flutter-handoff.md), [design traceability](design-traceability.md), [architecture](architecture.md), [analytics plan](analytics-plan.md), [backend contract](backend-contract.md), [test plan](test-plan.md), [README](../README.md).
- **Kết quả hiện hành:** [E1]-[E12] ở mục 12, đọc theo SHA/thời điểm. Tracker N-01/N-02/N-03 có evidence follow-up local trên branch hiện tại; N-04/N-05/N-06 còn mở theo điều kiện được nêu tại từng hàng. README, design plan, [bao-status](workstreams/bao-status.md) và [Firebase index](../evidence/firebase/manifest.md) vẫn có snapshot lịch sử, nên đọc theo mốc SHA/ngày tương ứng.
- Đề 18 trang cũ chỉ là lịch sử; **không tái sử dụng điểm rubric cũ** như được v5 xác nhận. V5 không nhắc lại mốc “ít nhất 8 màn”; BeeWise vẫn giữ mục tiêu **12 màn Lab 2**. V5 yêu cầu exploration 15-30 phút nhưng không ghi tier “Pro”; **Pro** là cấu hình kế hoạch repo cần giữ khi thực thi.
- Project đúng: `beewise-lab-3`; Android `com.beewise.beewise`. Chỉ dùng tài khoản/dữ liệu test được phép; không commit credentials, raw UID, token hay khóa mô hình.

## 2. Baseline repository/PR đã xác minh

Đã fetch ngày 02/11/2026; hiện local `main` khớp `origin/main` tại merge PR #5 `5df96fd3df995ea12747dcd218c418327d05db4c`.

| Mốc | Kết quả đã kiểm chứng |
|---|---|
| [PR #1 - Nguyên](https://github.com/YukikoKaori/beewise-lab2/pull/1) | MERGED; app/routes/harness/docs nền. |
| [PR #2](https://github.com/YukikoKaori/beewise-lab2/pull/2) | MERGED; merge `12f5322655463fd801d64e4925572d6a3a2bbb82`. Giữ các sửa security/lifecycle. |
| [PR #3](https://github.com/YukikoKaori/beewise-lab2/pull/3) | MERGED 02/11/2026; final source HEAD `b338346ce241250cbaaa4fed5c5208caa5290fde`; merge `55b11165a6505810f6c66a3736609d3b75aabb34`. |
| [PR #5 - N-01/N-02/N-03](https://github.com/YukikoKaori/beewise-lab2/pull/5) | MERGED 02/11/2026; head `a3e0252bf30be982a0a9164a2fba4c2ba2332a74`; merge `5df96fd3df995ea12747dcd218c418327d05db4c`. GitHub review submissions and review comments were empty when checked; this PR does not satisfy N-04 external review. |
| Local checks PR #3 | Format/analyze/debug APK PASS; **Flutter 66/66**, **Firebase Emulator rules 28/28**, parser 4/4, log/receipt [E1]. Không chạy lại app/cloud trong lượt docs-only này. |
| [Actions final PR #3 HEAD](https://github.com/YukikoKaori/beewise-lab2/actions/runs/41321277718) | **3/3 SUCCESS**, API xác nhận `headSha=b338346...`; `e2e-harness` collect/check cấu trúc, không phải ARTEMIS runtime. CI docs PR là lần kiểm tra riêng. |
| [Actions main sau merge](https://github.com/YukikoKaori/beewise-lab2/actions/runs/41384595579) | **3/3 SUCCESS** tại đúng `55b11165...`: flutter-android, firebase-rules, e2e-harness. |
| Default APK | App source `be2b44515af637db1c7ded6b94797d1cf4adc746`; default `lib/main.dart`, SHA-256 `2d3ed39e8eb5a5604571e15ef20322a00058853f9f773dd92d6397af814edd65`; build/install hash khớp, không dùng probe kết luận startup [E2]. |
| Submission | **PARTIALLY COMPLETE**: Storage, ba flow, QA và bộ nộp chưa đủ bằng chứng. Không giữ merge blocker cũ của PR #3 đã giải quyết. |

Ba cold **process** start API37 đã settle lên Home, process-to-draw **7,070 / 5,127 / 4,563 ms**, không BeeWise ANR, native Flutter first frame được xác nhận. Lần 3 Android báo `WARM` do giữ task nhưng PID mới. Có ảnh thật 360dp/412dp và navigation; warm 412dp 235 ms host wall [E2].

Giới hạn: headless emulator, chưa test release-mode/máy thật/API35-36; bốn lần ngay sau boot trước đó timeout/first draw 36-57 giây. Evidence hỗ trợ contention emulator/host, chưa chứng minh nguyên nhân độc quyền hay Flutter defect. Không gọi là “đã sửa mọi startup”.

## 3. Checklist yêu cầu mentor v5

`[x]` chỉ xác nhận phạm vi có bằng chứng ghi kèm; `[ ]` còn thiếu thực thi hoặc hồ sơ nộp. Owner/status/action ở mục 5-8.

- [ ] **App/ba flow** (v5 tr.1, 4): màn và **3 luồng Lab 2**, dữ liệu thật, loading/data/empty/error/recovery. Source có 12 màn; chưa chứng minh đủ ba flow live. Mốc ≥8 màn thuộc yêu cầu đầu vào/lịch sử, **không được v5 xác nhận lại**.
- [x] **Kiến trúc** (tr.1, 4): Riverpod/MVVM, View → ViewModel → Service → Firebase SDK; source có provider/controller/service boundary. Nguyên còn audit UI/Figma; kiến trúc không thay E2E.
- [ ] **Auth** (tr.5-7): Google, auth-state restore, cancel/logout, protected screens, lỗi mạng, ảnh app/Authentication Users Console. Runtime Email/Password + Google đã live verified [E3]; chốt ảnh Console trong gói nộp.
- [ ] **Storage** (tr.8-10): ít nhất một file (BeeWise dùng PDF), upload `reports/{uid}/...`, progress/download URL/success/error, owner-only rules, unauthorized/offline tests và tệp trong Console. **DEFERRED; bắt buộc, không optional.**
- [ ] **FCM** (tr.11-13): Android 13+ permission, foreground/background/terminated, inbox/tap; v5 yêu cầu gửi thử từ Console và kiểm tra từ chối quyền. Native delivery/tap/ownership đã verified [E4]; chốt Console-send và denial receipt.
- [x] **Analytics ≥7 business event types** (tr.14-16): DebugView thật cho `login`, `logout`, `search`, `view_tutor`, `ai_match_no_results`, `sign_up`, `export_report` [E5]. Không đếm SDK auto-events cho đủ bảy.
- [ ] **Analytics plan/evidence** (tr.15-16): trigger, kiểu tham số, câu hỏi sản phẩm, bước flow, ảnh từng event trong kế hoạch. Plan nhiều hơn bảy event; `upload_report`/workflow events chưa chạy không được gọi verified. Bảo/Nguyên chốt plan theo scope ba flow.
- [x] **Crashlytics** (tr.17-19): non-fatal từ lỗi Matching thực tế, deliberate fatal, custom keys và signed-in fatal User ID có Console receipts [E6]. Không suy rộng identity của mọi non-fatal hay logout clearing chưa kiểm tra.
- [ ] **Remote Config** (tr.20-22): ≥2 params đổi hành vi nhìn thấy trên cùng APK; defaults/offline/cache. Thay đổi thực tế và restore verified [E7]; chưa đủ ảnh Console giá trị trước/sau.
- [ ] **ARTEMIS** (tr.23): ≥10 ca có điều kiện/bước/kết quả; **mỗi ca ≥3 executions**; bao phủ Lab 2, một nhánh lỗi, một tương tác Android native; trace/JUnit/pass rate và kết quả quan sát. Harness 26 ca không thay thực thi [E8].
- [ ] **Exploration** (tr.23): một session **15-30 phút**, log thời lượng/issue. Repo chọn TC-25 **Pro 20 phút**; chưa có runtime receipt.
- [ ] **AI Code Review** (tr.24): review PR bằng Copilot/CodeRabbit/tương đương; **≥5 findings thuộc ≥2 nhóm**, file/line, quyết định/lý do; **sửa ≥3 findings accepted**, commit truy vết. V5 không ghi ba commit riêng; self-review hiện có không phải external approval [E9].
- [ ] **Nộp bài** (tr.25): GitHub, Console/test evidence, design/architecture/analytics docs; **report PDF 8-12 trang, slides PDF 12-15 trang, video 5-10 phút**. Có report PDF/slides PPTX **DRAFT**, chưa verified final/video [E10].
- [ ] **Ràng buộc BeeWise/Lab 2:** Firestore + strict rules, không submit hard-coded mocks, Figma/responsive **360dp/412dp**. V5 không ghi riêng hai bề rộng hoặc liệt kê Firestore trong sáu dịch vụ.

**Sáu dịch vụ:** Authentication, Storage, FCM, Analytics, Crashlytics, Remote Config. **Firestore là data store theo dõi riêng**; không thay Storage hoặc gọi thành “bảy dịch vụ bắt buộc” của v5.

## 4. Ownership và ranh giới file

| Phạm vi | Bảo | Nguyên |
|---|---|---|
| Chính | Cloud/data, Android/runtime, secure contracts, Console receipts | UI/Figma/responsive, ARTEMIS/E2E, AI review, report/slides/video |
| Source | `firebase/**`, `android/**`, `lib/services/**`, `lib/viewmodels/**`, `lib/models/**`, `lib/main.dart`, `pubspec.*` | `lib/screens/**`, `lib/widgets/**`, `lib/theme/**`, `lib/app/bee_wise_app.dart`, `e2e_test/**` |
| Docs/evidence | `docs/analytics-plan.md`, `docs/backend-contract.md`, `docs/workstreams/bao-*.md`; `evidence/firebase/**`, `evidence/android/**`, `evidence/cloud/**` | `docs/design-traceability.md`, `docs/test-plan.md`, `docs/code-review.md`, `docs/workstreams/nguyen-*.md`; `evidence/ui/**`, `evidence/artemis/**`, `evidence/ai-review/**` |
| Final integration | Bàn giao/duyệt đúng các claim cloud | Chốt `README.md`, `docs/architecture.md`, `docs/lab3-report.md`, `report/**`, `slides/**`, `output/**`, video sau handoff |

Mỗi người fetch latest main, branch/working copy riêng; không tiếp tục PR #2/#3 đã merge. Không sửa file owner khác nếu chưa thống nhất; interface chéo ghi handoff trước. Docs chung không edit song song. Phối hợp cửa sổ rules/RC, namespace/account/device test riêng; giữ privacy, strict rules, generation/journal/cross-UID/fail-closed protections. Lượt này thực hiện các sửa responsive nhỏ trong UI owner scope, bổ sung widget regression coverage và lưu runtime smoke evidence; không thay đổi cloud/config.

## 5. Bảng task Bảo (B-01 đến B-05)

| ID | Owner | Requirement | Status | Evidence | Next action | Dependency |
|---|---|---|---|---|---|---|
| B-01 | Bảo | Default Android APK; startup/runtime 360dp/412dp | PARTIALLY COMPLETE | Build + ba settled cold-process starts + native UI/navigation [E1] [E2] | Handoff receipts; kiểm tra máy thật/release/API35-36 khi có; giữ immediate-boot limitation | Device/toolchain; không clear userdata/suppress ANR |
| B-02 | Bảo | Auth + Firestore/role/data thật | PARTIALLY COMPLETE | Email/Password/Google/cancel/restore/logout, role recovery; strict rules/index deployed; **9/9 foreign authenticated reads denied** [E3] [E11] | Chốt Users Console receipt; catalog thật có quyền sử dụng; không gọi fixtures là real product data | Chủ dữ liệu/consent; Nguyên cùng chạy flow |
| B-03 | Bảo | Sáu Firebase services, nhánh lỗi | PARTIALLY COMPLETE | Năm dịch vụ có scoped runtime/Console proof; B-03.1-6 mục 7; Storage chưa live | Chốt Storage decision và receipts thiếu; không lặp test đã verified khi chưa có lý do | Owner billing/Blaze/bucket; cửa sổ Console |
| B-04 | Bảo | Trusted business workflows | PARTIALLY COMPLETE; trusted live E2E BLOCKED | Client/rules/unit boundaries có, contract [E12]; trusted producer/payment/schedule chưa live | Chốt ba flow; chỉ trusted staging tối thiểu nếu cần và được phép; không ưu tiên full processor trước Firebase/QA | Mentor/team chốt flow; staff/provider khi cần |
| B-05 | Bảo | Evidence/integration handoff | PARTIALLY COMPLETE | [E1]-[E7], [E11], hashes/audit; scope probe/default rõ | Bàn giao service → thao tác → SHA/APK/device/time → app/log/Console; bản che PII truy cập được, freeze trước demo | Nguyên nhận; private originals không tự là public link |

**B-02 đã đạt trong scope:** own Parent positive controls; A→B, B→A, Google→A đều bị deny foreign Parent/application/devices qua native SDK. Đây là **read negatives trên debug-only probe**, không Admin bypass hay live malicious-write test. Sáu catalog records là `[TEST]`/synthetic/unverified: đọc từ server nhưng **chưa đủ catalog thật**, AI loại chúng khỏi recommendations.

## 6. Bảng task Nguyên

Đã kiểm tra PR #1-#5, source/routes/docs/artifacts trên latest main. PR #5 thêm `evidence/artemis/` và `evidence/ui/`; GitHub API trả về không review submission/comment cho PR #5. Đây là trạng thái evidence hiện thấy trong repo, **không kết luận Nguyên chưa làm ở nơi khác**.

| ID | Owner | Requirement | Status | Evidence | Next action | Dependency |
|---|---|---|---|---|---|---|
| N-01 | Nguyên | 12 màn Lab 2, Figma/widgets/theme/router | PARTIALLY COMPLETE | All 12 supplied Figma PNGs exist and source audit covers all canonical routes. Existing runtime evidence covers Home/Search/AI and Login/Register at 360/412dp, Tutor Profile/Connection at 412dp, Messages/Profile and signed-in Messages empty state at both widths. Fresh post-merge Home at 360dp is recorded in `runtime-home-post-merge-360dp.png/.xml`; it shows all five tabs and a genuine empty state with zero cards. Home raster/frame parity remains unresolved. | Capture/compare Group Chat, Trial, Class, Payment and Schedule at 360/412dp; add Tutor Profile/Connection at 360dp; resolve Home frame dimensions when design reference is supplied | Five workflow screens need approved/trusted workflow data; final Figma comparison awaits design reference; ADB capture capability should be rechecked |
| N-02 | Nguyên | Responsive 360dp/412dp; loading/empty/error/recovery | PARTIALLY COMPLETE | `flutter test --no-pub` PASS **76/76** including new Chat empty-state coverage at 360/412dp and 1.8 text scale; `flutter analyze --no-pub` reports no issues; Dart format check reports 0 changed. Android 36 runtime Home smoke is captured at 360dp. Existing evidence covers several form keyboard/scroll and empty states. | Capture Android keyboard/safe-area/TalkBack behavior and data/loading/recoverable-error states at both widths using approved fixtures | Trusted workflow fixtures and Android accessibility review remain |
| N-03 | Nguyên | ARTEMIS ≥10 ca ×3 + exploration 15-30 phút | PARTIALLY COMPLETE (matrix NOT VERIFIED) | Test plan lists 27 functions, which is collection/structure only. Historical TC-01 **3 accepted PASS/17 attempts** and TC-09 **2 accepted PASS** are **REPORTED, not independently verified**: second AI re-review did not receive all original logs/JUnit/traces. In a fresh 2026-11-03 attempt, ADB and AVD were started; `emulator-5554` reached `device`, boot completed, BeeWise package/activity were present, and ARTEMIS health/device listing passed. Real TC-01 run 1/3 was **BLOCKED_QUOTA** by Gemini Free Tier HTTP 429 before UI assertions (trace `093516ef-8ae1-4b9a-b8e2-87e71ee4be17`); runner stopped the batch and preserved log/JUnit/manifest/trace at `evidence/artemis/n03-2026-11-03/tc01-priority-rerun/`. No other new cases or exploration were run. ARTEMIS/Android E2E not run during this remediation. See [remediation report](../evidence/external-review/BeeWise_N03_Remediation_Report.md). | Wait for ARTEMIS provider quota recovery under the authorized plan, recheck host/device/app preflight, verify case fixtures; execute ≥10 official eligible cases ×3 with raw logs/JUnit/trace; separately record 15–30 minute exploration. Keep failures/blocked/not-run distinct. | Available ARTEMIS host/quota; stable online AVD; approved staging catalog/account/workflow fixtures |
| N-04 | Nguyên | External AI review ≥5 findings/≥2 nhóm, ≥3 fixes | HUMAN REVIEW CONFIRMED BY OWNER; COMMIT/TRACEABILITY PENDING | Owner confirmed human reviewer sign-off in chat on 2026-11-03. Review findings F-01..F-06 and N-01..N-03 are recorded in [remediation report](../evidence/external-review/BeeWise_N03_Remediation_Report.md); fixes and regression checks are in working tree. No commit SHA or GitHub review record yet. | Preserve reviewer confirmation in project evidence if available; commit accepted fixes and record SHA(s); attach/link reviewer comments or written response if the course rubric expects an artifact. F-02 independent provenance caveat remains documented. | Remediation commit SHA; optional durable reviewer response artifact per rubric |
| N-05 | Nguyên | Final report PDF 8-12 trang, slides PDF 12-15 trang | PARTIALLY COMPLETE | Report PDF FINAL 9 trang đã render/kiểm tra; deck FINAL PPTX 13 slide đã qua structural validation (0 lỗi/cảnh báo); slide PDF chưa export được do lỗi thiếu alias font `#standard-fonts/Helvetica` trong Artifact Tool; alias hook cô lập cũng không tương thích metric format (`Invalid standard font data`). Nội dung ghi giới hạn N-01..N-06 theo evidence hiện tại. | Sửa/khắc phục export PDF slide trong runtime được hỗ trợ; kiểm tra trực quan toàn bộ 13 trang; Bảo rà soát cloud claims và links trước nộp | Xuất được slide PDF; review nội dung bởi Bảo |
| N-06 | Nguyên | Demo video 5-10 phút và final links | NOT COMPLETE | [Demo script](demo-script.md); chưa có video final 5-10 phút hoặc link chia sẻ đã kiểm tra trong repo. Không ghi hình thành công dịch vụ/flow đang blocked. | Sau khi chốt fixtures và evidence, quay demo thật 5-10 phút; kiểm tra link bằng hai tài khoản/quyền xem và lưu SHA/giới hạn | App/services/fixtures đủ cho các đoạn demo; evidence freeze |

### N-01/N-02 source audit (2026-11-02)

Source-to-Figma audit: [N1](../evidence/ui/source-audit-20261102.md). It maps all 12 canonical screens and routes, records acceptance checks and source-level observations, and separates checks that need an Android capture from issues that can be confirmed from source. The 12 primary supplied frames plus AI results state are indexed in [Figma evidence](../assets/figma-screens/README.md); 11 primary raster captures are 2x their listed 360px frames, while Home is 804x2400 against a 402x874 inspector frame, so Home pixel parity remains unresolved. No runtime visual parity is claimed.

Responsive/accessibility source review found scrollable form/detail layouts, safe-area handling for chat and tutor-profile footers, wrapped home subject chips, and 14sp body text. Three layout constraints were corrected: navigation height now matches the 72dp handoff, loading placeholders no longer force 178dp height, and chat bubbles derive maximum width from screen width. `responsive_layout_test.dart` covers 72dp navigation and TutorCard at 360/412dp with 1.8 text scale. `OnboardingStepper` follows the supplied four-step consultant flow, uses BeeWise state colors and exposes one progress label to accessibility. `workflow_empty_state_test.dart` covers stepper and Chat/Trial/Class/Payment/Schedule empty states at 360/412dp with 1.8 text scale. Latest verification: `flutter test --no-pub` **76/76 PASS**, `flutter analyze --no-pub` reports no issues, and format check reports 0 changed. Runtime captures/hierarchies cover Home/Search/AI at both widths; Login/Register at both widths; Tutor Profile/Connection at 412dp; Messages/Profile at 412dp; Login/Register keyboard/scroll; Home/Search/AI at font scale 1.3; and signed-in Messages empty state at both widths. A new post-merge Home 360dp screenshot/hierarchy is recorded in the runtime manifest. Five canonical screens (Group Chat, Trial, Class, Payment, Schedule) remain without runtime capture; Tutor Profile/Connection still need 360dp captures; full Figma, loading/data/error/recovery, keyboard and accessibility validation remains outstanding. Trusted workflow data is needed for data-dependent states.

## 7. Ma trận kiểm chứng sáu Firebase services

Mỗi hàng là subtask B-03 riêng. Status xét **đủ receipt v5**, không phủ nhận runtime PASS trong Evidence.

| ID | Owner | Requirement | Status | Evidence | Next action | Dependency |
|---|---|---|---|---|---|---|
| B-03.1 Auth | Bảo | Google/Email, restore/cancel/logout, protected/error states, Users Console | PARTIALLY COMPLETE (runtime COMPLETE trong scope) | Native A/B/Google + role/account-check recovery [E3] | Đính kèm/kiểm tra Users Console đã che PII cho gói nộp; không ghi thiếu Google Sign-In | Console access, private handoff |
| B-03.2 Storage | Bảo | PDF → `reports/{uid}/...` → progress/URL; owner rules, offline/error, Console | **DEFERRED - MANDATORY, NOT COMPLETE / NOT LIVE VERIFIED** | PDF local thật, `export_service.dart`, `firebase/storage.rules`, emulator tests [E1] [E5] | Owner quyết định/ủy quyền billing/Blaze/bucket; sau đó upload/download, cross-UID/offline/retry và Console thật | **Owner decision BLOCKED; code/emulator không thay cloud proof; cần trước final submission đủ chuẩn** |
| B-03.3 FCM | Bảo | Android 13+ permission/inbox, foreground/background/terminated, tap/ownership | PARTIALLY COMPLETE (delivery/lifecycle scoped COMPLETE) | First-login race fixed; native A/B/Google ownership, 3 states và terminated tap Search [E3] [E4] | Chốt riêng Console-send và permission-denied receipts theo tr.13; giữ generation/journal/quarantine | Account/device, phối hợp sender/Console |
| B-03.4 Analytics | Bảo | ≥7 business events, DebugView, typed non-PII params/identity | COMPLETE cho minimum bảy loại đã test | Bảy events mục 3; Google method; A→logout→guest→B→logout→guest, guest không `_id`, Console correlation [E5] | Handoff per-event receipts; đối chiếu plan/flow, không gọi mọi planned event verified | Nguyên ghép demo; events Storage/workflow theo task tương ứng |
| B-03.5 Crashlytics | Bảo | Real non-fatal, deliberate fatal, identity/keys, app recovery | COMPLETE cho scoped Console checks | Matching failure, fatal/custom keys, Google fatal User ID match [E6] | Bản che UID; ghi persisted keys không xác định fatal trigger; không suy rộng non-fatal identity/logout clear | Private originals + handoff |
| B-03.6 Remote Config | Bảo | ≥2 params đổi UI không rebuild; defaults/offline/cache; Console trước/sau | PARTIALLY COMPLETE (same-APK behavior COMPLETE) | Apply/restore `ai_matching_enabled`, `ai_result_limit`, `home_tutor_limit`; visible gate/limits + tests [E7] | Chốt ảnh Console giá trị trước/sau cùng ảnh app, giải thích fetch/cache; restore sau experiment | Owner authorization, coordinated RC window |

Analytics null clearing đã đủ native FA-SVC removal + complete guest bundles không `_id`, hai guest search tới DebugView. Console có thể giữ property lịch sử; **không tái mở blocker thiếu quyền/UID clearing cũ**, không đổi identity theo stale display. Không có event-level backend export; không suy rộng ngoài scope [E5].

**Firestore riêng:** strict rules/index deployed/verified [E11], native read negatives 9/9 [E3], unit/rules write negatives PASS; live malicious writes chưa chạy. Client không tự tạo verified tutor, paid invoice hay official schedule. Catalog thật và trusted workflow data còn mở ở B-02/B-04.

## 8. Ba flow và evidence công nghệ

Ba flow dưới đây từ traceability/test plan hiện có; không thay bằng ba demo Firebase rời rạc. Nếu thu hẹp flow thứ ba, team xin mentor xác nhận và cập nhật traceability; không tự gọi payment/schedule thành công.

| ID | Owner | Requirement | Status | Evidence | Next action | Dependency |
|---|---|---|---|---|---|---|
| F-01 | Nguyên + Bảo | Home → Search/AI → Tutor detail → auth gate → Request → Chat | PARTIALLY COMPLETE | Discovery/Auth native; request/chat source + rules; [test plan](test-plan.md) | Chạy trọn trên catalog thật, kiểm tra Firestore side effects/error/recovery, giữ tutor context qua login | Catalog + safe test parent |
| F-02 | Nguyên + Bảo | AI matching → tutor thật hoặc no-match/error → retry/Manual Search | PARTIALLY COMPLETE | Empty/disabled recovery + Analytics verified; [matching source](../lib/services/matching_service.dart) loại synthetic data | Nếu giữ AI success, chốt provider/terms/config được phép và catalog thật; ghi output thật | Owner/provider; không tự bật billing/App Check enforcement |
| F-03 | Nguyên + Bảo | Chat → trial → class revision → invoice → verified payment → official schedule | BLOCKED cho live E2E | Client/rules giữ trust boundary [E12]; chưa trusted producer/provider | Chốt scope công nghệ với mentor; full flow cần staging tối thiểu được phép/receipt-driven state, không tự dựng full processor | Trusted staff/proposals/issuer/provider hoặc scope được mentor duyệt |

Mỗi flow/service cần **source SHA, APK hash/entrypoint, device/OS/viewport, thời gian/lệnh, expected/observed, screenshot/video/log/trace, failure/recovery, Console/data link khi cần**. Không ghi PASS từ `SUCCESS`, mock, toast, API acceptance hay JUnit collection đơn lẻ. Không đưa credentials/PII vào model/trace. PDF local và `export_report` **không chứng minh Storage upload**.

## 9. Blockers và quyết định còn mở

1. **Storage bắt buộc / owner defer:** quyết định và ủy quyền billing/Blaze/bucket, rồi cloud evidence. Chưa quyết định thì DEFERRED/BLOCKED, không optional; lượt này không nâng plan, tạo bucket/deploy Storage.
2. **Catalog/ba flow:** chưa có catalog thật được phép; synthetic records không đủ. Chốt scope Lab 2/trusted staging khi cần; không nới rules demo payment/schedule.
3. **QA:** ARTEMIS host, Gemini credential and Android 36 emulator đã hoạt động cho smoke runs; xem kết quả và giới hạn mới nhất ở N-03/test plan. Ma trận ≥10 ca ×3, phiên Pro và external review vẫn chưa đủ evidence. Các ca cần catalog/staging phải có fixtures riêng được duyệt. N-04 cần reviewer ngoài trên implementation PR sau khi mở PR; không suy diễn private evidence ngoài repo.
4. **Gói nộp:** Users Console, FCM Console-send/denied permission, RC parameter before/after; chuyển private receipts thành bản chia sẻ đã che PII. DRAFT/PPTX không thay final PDFs/video.
5. **Android:** immediate-boot API37 và physical/release/API35-36 chưa kiểm tra toàn diện. Giới hạn sau scoped startup PASS, không giữ PR #3 đã merge chờ sửa vô hạn.

## 10. Thứ tự tiếp theo P0/P1/P2

| ID | Owner | Requirement | Status | Evidence | Next action | Dependency |
|---|---|---|---|---|---|---|
| P0-1 | Chủ project + Bảo | Quyết định Storage | BLOCKED (implementation DEFERRED) | B-03.2 | Quyết định/ủy quyền billing/Blaze/bucket hoặc ghi rủi ro thiếu v5 trước hạn nộp; chưa được phép không thao tác cloud | Owner decision |
| P0-2 | Bảo + Nguyên | Catalog/ba flow và evidence handoff | PARTIALLY COMPLETE | B-02/B-04/B-05, [E3] [E12] | Chốt data thật, ba flow và ma trận receipts còn thiếu; bàn giao kết quả đã chốt | Chủ dữ liệu, mentor nếu đổi scope |
| P0-3 | Nguyên | ARTEMIS/Pro và external review | NEEDS VERIFICATION | N-03/N-04, [E8] [E9] | Xác nhận host/key/device; ≥10 ca ×3 + Pro 15-30 phút; ≥5 findings/≥2 nhóm, ≥3 fixes và commits | Host/key, device/data, review tool |
| P1-1 | Bảo | Storage live và Console packet | PARTIALLY COMPLETE | B-03.1-6 | Sau authorization: Storage live/error/ownership; chốt Auth/FCM/RC receipts, tránh rerun vô ích | P0-1/P0-2, cửa sổ Console |
| P1-2 | Nguyên; Bảo review cloud | UI/responsive, final PDFs/video/links | PARTIALLY COMPLETE | N-01/N-02/N-05/N-06, [E10] | Audit UI, integration freeze và đóng gói bản nộp thật | P0-2/P0-3, Storage |
| P2-1 | Bảo + Nguyên | Mở rộng validation/product nếu scope cần | NEEDS VERIFICATION | B-01/B-04, [E2] [E12] | Physical/release/API35-36 khi có; pagination >100, quota/inbox/backend projection khi cần; không để full payment/backend lấn mandatory Firebase/ARTEMIS/demo | Device hoặc product contract được duyệt |

## 11. Git handoff (2026-11-03)

PR #5 (`a3e0252`) containing earlier N-01/N-02 and partial N-03 work was merged into `main` at `5df96fd`. This follow-up is on `codex/beewise-lab3-nguyen-followup`; UI captures, widget-test fix, ARTEMIS parser/runner improvements, follow-up evidence, refreshed report PDF and validated review PPTX are local changes and have not been committed or pushed. Slide PDF export remains incomplete due the bundled Artifact Tool font-alias error and incompatible packaged metric data. Review `git status` and `git diff --check` before handoff. N-03 remains PARTIALLY COMPLETE until its matrix and Pro exploration are verified.

For the next implementation change, start a new branch from the updated `main`:

```powershell
git status --short
git diff --check
git switch main
git pull --ff-only origin main
git switch -c codex/<next-task>
```

Do not stage local secrets, `.env`, generated build output, or temporary ARTEMIS configuration. Commit and push task changes on the new branch, then open a PR into `main`.

## 12. Checklist tích hợp và nộp cuối

- [x] PR #2/#3 đã merge; baseline main/source/SHA/CI ghi đúng.
- [ ] Workstreams cập nhật newest main; checks trên integration HEAD, không dùng PR #3 CI thay kiểm tra code mới.
- [ ] 12 màn audit Figma, responsive 360dp/412dp đủ scope, loading/empty/error/recovery.
- [ ] Ba flow Lab 2 chạy E2E thật; không hard-coded submitted catalog/giả payment/schedule.
- [ ] Sáu Firebase services + Firestore, mỗi service có nhánh lỗi; **Storage upload/URL/Console/ownership live hoàn tất**.
- [ ] Analytics plan/receipts khớp; Auth/FCM/Crashlytics/RC có gói Console/app/log reviewable, không lộ PII.
- [ ] ARTEMIS ≥10 ca ×3, Pro exploration 15-30 phút, traces/JUnit/pass rates, phân loại flaky/fail/blocked thật.
- [ ] External review ≥5 findings/≥2 nhóm; dispositions/lý do và ≥3 accepted fixes có commit truy vết.
- [x] Report PDF 8-12 trang: FINAL 9 pages, rendered and visually inspected.
- [ ] Slides PDF 12-15 trang: 13-slide PPTX validated, but required PDF export is still blocked; video 5-10 phút and verified final links are also outstanding. Bảo must review cloud claims and two viewers must check link permissions.
- [ ] Repo/design/architecture/analytics/test docs/evidence index khớp final SHA; không dùng DRAFT/PPTX thay final PDF. Không tự merge PR docs này.

## 12. Evidence references và status conventions

| Ref | Nguồn audit | Phạm vi / cách đọc |
|---|---|---|
| [E1] | [Controlled validation](../evidence/cloud/pr3-controlled-validation.json), [check logs](../evidence/cloud/checks/pr3-controlled/) | 66 Flutter / 28 emulator rules / build; không là live Storage/ARTEMIS. |
| [E2] | [Native manifest](../evidence/android/pr3-controlled/manifest.json), [diagnosis](workstreams/bao-reliability.md) | Default APK/control, widths/first frame/limitations; đọc section mới nhất trước history. |
| [E3] | [Google runtime](../evidence/cloud/google-runtime-validation.json), [reliability](../evidence/cloud/reliability-validation.json) | Auth, role/FCM fix, 9/9 probe read denials; verdict UID/startup cũ được E2/E5 supersede. |
| [E4] | [Terminated tap](../evidence/android/pr3-completion/terminated-tap-sequence.json), [follow-up](../evidence/cloud/pr3-followup-validation.json) | Background; terminated PID absent trước send, receiver PID, actual Search 12.84s/18.47s; Home-only cũ không là route proof. |
| [E5] | [Seven events](../evidence/cloud/reliability-validation.json), [native identity](../evidence/cloud/pr3-identity-native-final.json), [DebugView](../evidence/cloud/pr3-debugview-correlation.json) | Bảy loại là union receipts cũ/mới; null clearing + guest events verified, stale properties không là blocker mới. |
| [E6] | [Console fatal/non-fatal](../evidence/cloud/console-runtime-validation.json), [fatal identity](../evidence/cloud/google-runtime-validation.json) | Matching failure + deliberate fatal/keys/Google UID; private originals có hashes; không suy rộng non-fatal/logout identity. |
| [E7] | [RC roundtrip](../evidence/cloud/remote-config-roundtrip.json), [native before/after](../evidence/firebase/remote-config/README.md) | Same-APK gate/limits, defaults và restore; thiếu Console values receipt, không thiếu thay đổi hành vi thật. |
| [E8] | [Test plan](test-plan.md), [harness](../e2e_test/), [blocked preflight](../evidence/corrective/artemis-latest-blocked.json) | Authored/collect/preflight; chưa committed execution traces/JUnit. Hỏi Nguyên về evidence ngoài repo. |
| [E9] | [Review record](code-review.md), [PR #2 lifecycle review](pr2-lifecycle-review.md) | Internal Codex findings/fix commits có; external transcript/approval NOT VERIFIED. |
| [E10] | [Report source](lab3-report.md), [FINAL report PDF](../output/pdf/BeeWise-Lab3-Implementation-Report-FINAL.pdf), [FINAL 13-slide PPTX](../output/presentations/BeeWise-Lab3-Review-FINAL.pptx), [historical draft PDF](../output/pdf/BeeWise-Lab3-Implementation-Report-DRAFT.pdf), [historical draft PPTX](../output/presentations/BeeWise-Lab3-Review-DRAFT.pptx), [demo plan](demo-script.md) | Report PDF final has 9 rendered pages. PPTX passes structural/layout checks; mandatory slide PDF export remains unavailable in current Artifact Tool runtime. Neither final artifact closes N-05 until the slide PDF is produced/reviewed and Bảo signs off claims/links. |
| [E11] | [Rules deploy](../evidence/cloud/authorized-deploy-rules.json), [index deploy](../evidence/cloud/authorized-deploy-indexes.json), [release state](../evidence/cloud/firestore-release-state.json) | Authorized strict bundle, index READY trước rules release; khác local rules tests. |
| [E12] | [Trusted contract](backend-contract.md), [workflow status](workstreams/bao-workflow-status.md), [UI handoff](workstreams/bao-ui-handoff.md) | Boundaries/history; account/rules blocker cũ superseded E3/E11; trusted live processor chưa proof. |
| [N1] | [UI source audit](../evidence/ui/source-audit-20261102.md), [runtime manifest](../evidence/ui/runtime-manifest-20261102.md) | 12-screen route/Figma/source review plus partial Android 36 runtime screenshots/UI hierarchies; not a complete visual/accessibility matrix. |

[E1]: ../evidence/cloud/pr3-controlled-validation.json
[E2]: ../evidence/android/pr3-controlled/manifest.json
[E3]: ../evidence/cloud/reliability-validation.json
[E4]: ../evidence/android/pr3-completion/terminated-tap-sequence.json
[E5]: ../evidence/cloud/pr3-debugview-correlation.json
[E6]: ../evidence/cloud/google-runtime-validation.json
[E7]: ../evidence/cloud/remote-config-roundtrip.json
[E8]: test-plan.md
[E9]: code-review.md
[E10]: lab3-report.md
[E11]: ../evidence/cloud/firestore-release-state.json
[E12]: backend-contract.md
[N1]: ../evidence/ui/source-audit-20261102.md

**COMPLETE:** hàng có evidence đủ trong scope nêu. **PARTIALLY COMPLETE:** có code/kết quả, thiếu bước/receipt bắt buộc. **NOT STARTED:** đã xác nhận chưa bắt đầu. **BLOCKED:** thiếu dependency cụ thể. **DEFERRED:** owner hoãn, không miễn yêu cầu. **NEEDS VERIFICATION / NOT VERIFIED:** thiếu evidence kết luận, không đồng nghĩa owner chưa làm.

**PASS/FAIL/NOT RUN** mô tả từng phép kiểm tra, không thay status cả task. Phân biệt source, mock/unit, Firebase Emulator rules, CI APK, native emulator, physical device, live Console/service. Giữ evidence gốc/lịch sử tại link; tracker chỉ giữ trạng thái hiện hành, không chép nối snapshots mâu thuẫn.
